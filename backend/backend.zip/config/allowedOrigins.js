const allowedOrigins = [
    'http://localhost:3000',
    'https://crypwellinvest.com',
    'https://api.crypt.crypwellinvest.com',
    'http://localhost:3500'
]

module.exports = allowedOrigins;